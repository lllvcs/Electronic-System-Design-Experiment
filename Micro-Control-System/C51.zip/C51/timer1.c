#include<reg52.h>
#define uchar unsigned char
#define uint unsigned int
#define ulong unsigned long
uchar code table[]={
0x3f,0x06,0x5b,0x4f,
0x66,0x6d,0x7d,0x07,
0x7f,0x6f,0x77,0x7c,
0x39,0x5e,0x79,0x71};
// ----------------------??-?????? ??? 
uchar code  FREQH[] = {	
0xF2,0xF3,0xF5,0xF5,0xF6,0xF7,0xF8,     //??1234567
0xF9,0xF9,0xFA,0xFA,0xFB,0xFB,0xFC,     //??1234567
0xFC,0xFC,0xFD,0xFD,0xFD,0xFD,0xFE,		//??1234567
0xFE,0xFE,0xFE,0xFE,0xFE,0xFE,0xFF}; 	//??? 1234567
// ---------------------??-?????? ???
uchar code  FREQL[] ={ 
0x42, 0xC1, 0x17, 0xB6, 0xD0, 0xD1, 0xB6, //??1234567
0x21, 0xE1, 0x8C, 0xD8, 0x68, 0xE9, 0x5B, //??1234567
0x8F, 0xEE, 0x44, 0x6B, 0xB4, 0xF4, 0x2D, //??1234567
0x47, 0x77, 0xA2, 0xB6, 0xDA, 0xFA, 0x16};//??? 1234567
//-----------------------??????----------------------------------------------                //?????????????????????????????(??????)                     
code uchar hls[] = {				//??????
5, 2 ,2 ,2, 2, 2, 1, 2 ,2, 7 ,1, 1, 6,1 ,1, 5 ,1, 2 ,5, 2, 2 ,2, 2, 2, 3, 2 ,1 ,2 ,2, 1, 1 ,2, 2 ,1 ,2, 1 ,
6 ,1 ,1, 2, 2 ,1 ,3 ,2, 1, 2, 2 ,1, 1, 2 ,1 ,2, 2 ,1 ,1, 2 ,1, 7 ,1 ,1 ,6, 1, 1, 5, 1, 4, 5, 1, 2 ,0,0,0
};    


sbit beer=P1^6;
void delayms(uint);
void keyscan();
void display_0(uint);			//????
void display_1(uint,uint,uint);//????,??,???
void display_2(uint,uint,uint); //??????
void display_3(uint,uint) ;     //????
void display_4(uint,uint,uint);	//????
void delay(uchar);
void song();
void tishiyin();
void send(uint);

uint miao_shi,miao_ge,fen_shi,fen_ge,hour_shi,hour_ge;
uint day_shi,day_ge,month_shi,month_ge,year_qian,year_bai,year_shi,year_ge;
uint fensz_shi,fensz_ge,hoursz_shi,hoursz_ge;
uint ms_shi,ms_ge,sec_shi,sec_ge,min_shi,min_ge;
uint ms,miao,fen,hour,fen_sz,hour_sz,day=15,month=1,year=2013,mbms,sec,min,ds_ms;
uint ds_miao,ds_fen,ds_hour,ds_miao1,en_miaobiao,en_dingshi,en_naozhong,en_tsy;
uchar timer0h, timer0l, time;
ulong a;
//-------------------???---------------------------------------
void main()
{
	TMOD=0x11;			  	//???0,1???????
	TH0=(65536-45872)/256;	//???0???,?50ms????
    TL0=(65536-45872)%256;
	TH1=(65536-9174)/256; 	// ???1???,?10ms????
	TL1=(65536-9174)%256;
    EA=1;                   //??????
    ET0=1;                  //?????0??
    TR0=1;					//?????0
	ET1=0;
	TR1=0;            
    while(1)				//??????
    { 
		keyscan();
    }
}
//------------------??????----------------------------------//key1=0,1,2,3,4??????,??????????????
void keyscan()
{   
	uint key1,key21,key22,key23,key41;
	WR=0;				    //??U5??
	P0=0x00; 
	P2=0x80;                         
	P0=0x02;               //???????????(key1????)
	RD=1;
	WR=1; 				   //??U5??                         
	P0=0x00;
	RD=0;				   //??U15??????,????????,???U5,??U15,?????,P0??????						                      
	if(P0==0x01)		    	//?????????,key1++				
	{	delayms(20);			//????
		if(P0==0x01)
		{	
			while(P0==0x01);
			key1++;
			key21=0;
			key22=0;
			key23=0;
			key41=0;
		    if(key1==5)
  		    	key1=0;
		}
	}
//-------------------?????????----------------------------------------------------------
	if(key1==0)								//????????,???????????,??????,		   
	{
		if(P0==0x02)
		{
			delayms(20);
			if(P0==0x02);
			{
				while(P0==0x02);
				RD=1;
				display_2(year,month,day);
			}
		}
		else
		{
			RD=1;
			display_1(miao,fen,hour);
		}
	}
//	a=hour*3600+fen*60+miao;

//-------------????----------------------------------------------------------------------------
    if(key1==1)		//???????,????,??????0,1,2,3,4,5??????,??,?,?,?+,?-
	{ 
		if(P0==0x02)							
		{
        	delayms(20);
			if(P0==0x02)
			{
				while(P0==0x02);
				key21++;
				if(key21==5)
					key21=0;
			}
		}
		if(P0==0x08)
		{	delayms(20);
			if(P0==0x08)
			{	while(P0==0x08);
				key41++;
				if(key41==2)
					key41=0;
			}
		}
	}    
	if(key1==1&&key21==0&&P0==0x04)            
	{
	    delayms(20);
		if(P0==0x04)
		{
			while(P0==0x04);
			if(key41)
			{	if(fen==0)
				{	fen=fen+60;
				//	hour--;
				}
				fen--;
			}
			if(key41==0)
			fen++;
        }
	}
	
	if(key1==1&&key21==1&&P0==0x04)           
	{
	    delayms(20);
		if(P0==0x04)
		{
			while(P0==0x04);
			if(key41)
			{	if(hour==0)
				{	hour=hour+24;
					//day--;
				}
					hour--;
			}
			if(key41==0)
			hour++;
		}
	}
   	if(key1==1&&key21==2&&P0==0x04)
	{
		delayms(20);
	   	if(P0==0x04)
		{
			while(P0==0x04);
				if(key41)
				{	//day--;
					if(day==1)
					{	if(month==1||month==3||month==5||month==7||month==8||month==10||month==12)
						day=day+30;
						if(month==4||month==6||month==9||month==11)
						day=day+29;
						if(month==2)
						{	if(year%400==0||(year%4==0&&year%100!=0))
							day=day+28;
							else 
							day=day+27;
						}
					//	month--;
					}
					day--;
				}
				if(key41==0)
			   	day++;
		}
	}  
	if(key1==1&&key21==3&&P0==0x04)
	{
		delayms(20);
		if(P0==0x04)
		{
			while(P0==0x04);
			if(key41)
			{	if(month==1)
				{	month=month+12;
					//year--;
				}
				month--;
			}	
			if(key41==0)
			month++;
		}
	}
	if(key1==1&&key21==4&&P0==0x04)
	{
		delayms(20);
		if(P0==0x04)
		{
			while(P0==0x04);
			if(key41)
			year--;
			if(key41==0)
			year++;
		}
	}
	/*if(key1==1&&key21==5&&P0==0x04)
	{
		delayms(20);
		if(P0==0x04)
		{
			while(P0==0x04);
			year--;
		}
	}*/
	send(hour);
	send(fen);
	send(miao);
//-------------????--------------------------------------
	if(key1==2)                             
	{
		if(P0==0x02)							
		{
        	delayms(20);
			if(P0==0x02)
			{
				while(P0==0x02);
				key22++;
				if(key22==3)
					key22=0;
			}
		}
	}
	if(key1==2&&key22==0&&P0==0x04)	//key22=0,1,2,????,??????,??
	{
		delayms(20);
		if(P0==0x04)
		{
			while(P0==0x04);
			en_naozhong=~en_naozhong;
		}		
	}	
	if(key1==2&&key22==1&&P0==0x04)                            
	{	
		delayms(20);
		if(P0==0x04)
		{	
			while(P0==0x04);
			fen_sz++;
		}
	}
	if(key1==2&&key22==2&&P0==0x04)             
	{
		delayms(20);
		if(P0==0x04)
		{
			while(P0==0x04);
			hour_sz++;
		}
	}
	if(en_naozhong&&fen_sz==fen&&hour_sz==hour&&miao==0)
	{	en_naozhong=~en_naozhong;
		tishiyin();
		
	}	
//------------????--------------------------------------------------
	if(key1==3)
	{
		if(P0==0x04)
		{
			delayms(20);
			if(P0==0x04)
			{
				while(P0==0x04);
				en_miaobiao=~en_miaobiao;
				ET1=1;
				TR1=~TR1;
			}
		}
		if(~en_miaobiao&&P0==0x02)
		{
			mbms=0;
			sec=0;
			min=0;
		}
	}
//------------------?????-------------------------------------------------
	if(key1==4)
	{
		if(P0==0x02)
		{
			delayms(20);
			if(P0==0x02);
			{
				while(P0==0x02);
				key23++;
				if(key23==4)
					key23=0;
			}
		}
	}
	if(key1==4&&key23==0&&P0==0x04)
	{
		delayms(20);
		if(P0==0x04)
		{	while(P0==0x04);
			en_dingshi=~en_dingshi;
			ET1=1;
			TR1=~TR1;
		}
	}
	if(key1==4&&key23==1&&P0==0x04)
	{
		delayms(20);
		if(P0==0x04)
		{	while(P0==0x04);	
			ds_miao++;
		}
	}
	if(key1==4&&key23==2&&P0==0x04)
	{
		delayms(20);
		if(P0==0x04)
		{	while(P0==0x04);
			ds_fen++;
		}
	}
	if(key1==4&&key23==3&&P0==0x04)
	{
		delayms(20);
		if(P0==0x04)
		{	while(P0==0x04);
			ds_hour++;
		}
	}
	if(en_dingshi)
	{	
		ds_miao=ds_miao-ds_miao1;
		ds_miao1=0;
		if(ds_miao==-1)
		{	ds_miao=59;
			ds_fen--;
		}
		if(ds_fen==-1)
		{	ds_fen=59;
			ds_hour--;
		}
		if(ds_hour==0&&ds_fen==0&&ds_miao==0)
		{	en_dingshi=~en_dingshi;
			tishiyin();
		}
	}
//------------------?????---------------------------------------------------------------
	switch(key1)
	{	case 1:				
			RD=1;
			switch(key21)
			{
				case 0:
					display_0(0x18);
					display_1(miao,fen,hour);
					break;
				case 1:
					display_0(0xc0);
					display_1(miao,fen,hour);
					break;
				case 2:
					display_0(0x03);
					display_1(day,month,year);
					break;
				case 3:
					display_0(0x18);
					display_1(day,month,year);
					break;
				case 4:
					display_0(0xc0);
					display_1(day,month,year);
					break;
				case 5:
					display_0(0xc0);
					display_1(day,month,year);
			}
			break;
		case 2:			
			RD=1;
			switch(key22)
			{
				case 1:
					display_0(0x03);
					break;
				case 2:
					display_0(0x18);
					break;
			}
			display_3(fen_sz,hour_sz);
			break;
		case 3:				
			RD=1;
			display_4(mbms,sec,min);
			break;
		case 4:
			RD=1;
			switch(key23)
			{
				case 1:
					display_0(0x03);
					break;
				case 2:
					display_0(0x18);
					break;
				case 3:
					display_0(0xc0);
					break;
			}
			display_1(ds_miao,ds_fen,ds_hour);
			break;
	}
}	
//--------------------------???????----------------------------------------------------------
void display_0(uint x)
{
	WR=0;
	P2=0x81;
	P0=x;
	P2=0x91;
	P0=0x80;
	delayms(1);
}
//----------------------??,??,???????-----------------------------------------
void display_1(uint miao,uint fen,uint hour)	//????,??,???
{
	miao_shi=miao/10;	//?????,?????,??,??
    miao_ge=miao%10;
	fen_shi=fen/10;
	fen_ge=fen%10;
	hour_shi=hour%100/10;
	hour_ge=hour%10;
	WR=0;
    P2=0x81;			//??
    P0=0x80;
    P2=0x91;		    //??
    P0=table[hour_shi];
    delayms(1);
    P2=0x81;
    P0=0x40;
    P2=0x91;
    P0=table[hour_ge];
    delayms(1);
	P2=0x81;
	P0=0x20;
	P2=0x91;
	P0=0x40;
	delayms(1);
        
	P2=0x81;
    P0=0x10;
    P2=0x91;
    P0=table[fen_shi];
    delayms(1);
    P2=0x81;
    P0=0x08;
    P2=0x91;
    P0=table[fen_ge];
    delayms(1);
    P2=0x81;
	P0=0x04;
	P2=0x91;
	P0=0x40;
	delayms(1);

 	P2=0x81;
    P0=0x02;
    P2=0x91;
    P0=table[miao_shi];
    delayms(1);
    P2=0x81;
    P0=0x01;
    P2=0x91;
    P0=table[miao_ge];
    delayms(1);   
}
//----------------------????????-------------------------------------------
void display_2(uint year,uint month,uint day)	//??????
{   
	uint i,j;
	day_shi=day/10;
	day_ge=day%10;
	month_shi=month/10;
	month_ge=month%10;
	year_qian=year/1000;
	year_bai=year%1000/100;
	year_shi=year%100/10;
	year_ge=year%10;
    WR=0;
	P0=0x00;
	j=3;
	while(j)
	{	i=200;
    	while(i>0)
    	{  
			P2=0x80;
            P0=0x80;
            P2=0x91;
		    P0=table[year_qian];
            delayms(1);
	        P2=0x80;
	        P0=0x40;
	        P2=0x91;
	        P0=table[year_bai];
            delayms(1);
	    	P2=0x80;
	 	    P0=0x20;
	        P2=0x91;
	        P0=table[year_shi];
            delayms(1);
			P2=0x80;
	        P0=0x10;
	        P2=0x91;
	        P0=table[year_ge]; 
            delayms(1);
	        P2=0x80;
	        P0=0x08;
	        P2=0x91;
	        P0=0x08;
            delayms(1);
			P2=0x80;
	        P0=0x04;
  	        P2=0x91;
            P0=table[month_shi];
            delayms(1); 
			P2=0x80;
	        P0=0x02;   
	        P2=0x91;
	        P0=table[month_ge]; 
            delayms(1);
            P2=0x80;
	        P0=0x01;
	        P2=0x91;
	        P0=0x08;
            delayms(1);
		    i--;
		}
		i=200;
		while(i>0)
    	{  
			P2=0x80;
            P0=0x80;
            P2=0x91;
		    P0=table[month_shi];
            delayms(1);
	        P2=0x80;
	        P0=0x40;
	        P2=0x91;
	        P0=table[month_ge];
            delayms(1);
	    	P2=0x80;
	 	    P0=0x20;
	        P2=0x91;
	        P0=0x08;
            delayms(1);
			P2=0x80;
	        P0=0x10;
	        P2=0x91;
	        P0=table[day_shi]; 
            delayms(1);
	        P2=0x80;
	        P0=0x08;
	        P2=0x91;
	        P0=table[day_ge];
            delayms(1);
			P2=0x80;
	        P0=0x04;
  	        P2=0x91;
            P0=0x08;
            delayms(1); 
			P2=0x80;
	        P0=0x02;   
	        P2=0x91;
	        P0=table[year_qian]; 
            delayms(1);
            P2=0x80;
	        P0=0x01;
	        P2=0x91;
	        P0=table[year_bai];
            delayms(1);
		    i--;
		}
		i=200;
    	while(i>0)
    	{  
			P2=0x80;
            P0=0x80;
            P2=0x91;
		    P0=table[day_shi];
            delayms(1);
	        P2=0x80;
	        P0=0x40;
	        P2=0x91;
	        P0=table[day_ge];
            delayms(1);
	    	P2=0x80;
	 	    P0=0x20;
	        P2=0x91;
	        P0=0x08;
            delayms(1);
			P2=0x80;
	        P0=0x10;
	        P2=0x91;
	        P0=table[year_qian]; 
            delayms(1);
	        P2=0x80;
	        P0=0x08;
	        P2=0x91;
	        P0=table[year_bai];
            delayms(1);
			P2=0x80;
	        P0=0x04;
  	        P2=0x91;
            P0=table[year_shi];
            delayms(1); 
			P2=0x80;
	        P0=0x02;   
	        P2=0x91;
	        P0=table[year_ge]; 
            delayms(1);
            P2=0x80;
	        P0=0x01;
	        P2=0x91;
	        P0=0x08;
            delayms(1);
		    i--;
		}
	j--;
	}
	display_1(miao,fen,hour);
}
//------------------??????------------------------------------------------
void display_3(uint fen_sz,uint hour_sz)
{
	fensz_shi=fen_sz/10;
	fensz_ge=fen_sz%10;
	hoursz_shi=hour_sz/10;
	hoursz_ge=hour_sz%10;
	WR=0;
	P2=0x81;
	P0=0x10;
	P2=0x91;
	P0=table[hoursz_shi];
	delayms(1);
	P2=0x81;
	P0=0x08;
	P2=0x91;
	P0=table[hoursz_ge];
	delayms(1);
	P2=0x81;
	P0=0x04;
	P2=0x91;
	P0=0x40;
	delayms(1);
	P2=0x81;
	P0=0x02;
	P2=0x91;
	P0=table[fensz_shi];
	delayms(1);
	P2=0x81;
	P0=0x01;
	P2=0x91;
	P0=table[fensz_ge];
	delayms(1);
}
//----------------??????---------------------------------------------
void display_4(uint mbms,uint sec,uint min)
{
	ms_shi=mbms/10;
	ms_ge=mbms%10;
	sec_shi=sec/10;
	sec_ge=sec%10;
	min_shi=min/10;
	min_ge=min%10;
	WR=0;
	P2=0x81;
	P0=0x20;
	P2=0x91;
	P0=table[min_shi];
	delayms(1);
	P2=0x81;
	P0=0x10;
	P2=0x91;
	P0=table[min_ge];
	delayms(1);
	P0=0x80;
	delayms(1);

    P2=0x81;
    P0=0x08;
    P2=0x91;
    P0=table[sec_shi];
    delayms(1);
    P2=0x81;
	P0=0x04;
	P2=0x91;
	P0=table[sec_ge];
	delayms(1);
	P0=0x80;
	delayms(1);

    P2=0x81;
    P0=0x02;
    P2=0x91;
    P0=table[ms_shi];
    delayms(1);
    P2=0x81;
    P0=0x01;
    P2=0x91;
    P0=table[ms_ge];
    delayms(1);   
}
//-----------????-----------------------------
void delayms(uint xms)                //??50ms
{
	uint i,j;
	for(i=xms;i>0;i--)
		for(j=110;j>0;j--);
}
//------------?????--------------------------------------------------------------
void delay(uchar t)		//??t?
{	uchar t1;
	ulong t2;
	RD=1;
    for(t1 = 0; t1 < 16*t; t1++)
	{
		display_1(miao,fen,hour);
		for(t2 = 0; t2 < 500; t2++);
	}
	TR1 = 0;
}
//----------??????--------------------
void song()
{	TH1=timer0h;
	TL1=timer0l;
	TR1=1;
	delay(time);
}
//---------------?????------------------------
void tishiyin()
{	uchar i,k;
	en_tsy=1;
	ET1=1;
	i = 0;
 	time = 1;
	
	while(time) 
	{	k = hls[i] + 7 * hls[i + 1] -1; //?i????, ?i+1???????
	    timer0h = FREQH[k];                     //???????????
		timer0l = FREQL[k];                     //???, ????????
		time = hls[i + 2];                  //????????
		i += 3;
		song();
	/*	if(P0==0x04)
		{	delayms(10);
			if(P0==0x04)
			{	while(P0==0x04);
					time=0;
			}
		}
	}
	en_tsy=0;
	beer=1;*/
    WR=0;				//?U5??,??2?????????????(??key1????)
	P0=0x00;
	P2=0x81;
	P0=0x02;
	WR=1;				//?U5??,?key1?????
	P0=0x00;			
	RD=0;				//???????U15???,?DIR???,????,??2???????????????P0?
	if(P0==0x04)
	{
		delay(10);
		if(P0==0x04)
		{	while(P0==0x04);
			time=0;
		}
	}
   }
en_tsy=0;
beer=1;
}


//----------????-------------------------------
void T0_time() interrupt 1		//???0????
{
	TH0=(65536-45872)/256;		//????????
    TL0=(65536-45872)%256;
    ms++;
	if(en_dingshi)
		ds_ms++;
	if(ds_ms==20)
	{	ds_ms=0;
		ds_miao1++;
	}
    if(ms==20)
    {	ms=0;
        miao++;
	}
    if(miao==60)
    {  	miao=0;
		fen++;
	}

	if(fen==60)
	{	fen=0;
		hour++;
	}	
	if(hour==24)
	{ 	hour=0;
		day++;
	}
				   if((month==1 || month==3 || month==5 ||month==7||month==8||month==10|month==12) && day==31)
				    {	day=1;
					    month++;
					}
					if((month==4||month==6||month==9||month==11)&& day==30)
					{	day=1;
						month++;
					}
					if(month==2)
					{	if(year%400==0||(year%4==0&&year%100!=0))
						{	if(day==30)
							{	day=1;
								month++;
							}
						}
						else if(day==29)
						{	day=1;
							month++;
						}
					}
					    if(month==13)
					    {
					    	month=1;
							year++;
							if(year==13)
								year=1;
					    }  
					
}


void T1_time() interrupt 3		//???1????
{	if(en_tsy)
	{	TR1=0;
		beer=!beer;
		TH1=timer0h;
		TL1=timer0l;
		TR1=1;
	}
	else
	{	TH1=(65536-9174)/256;
    	TL1=(65536-9174)%256;
		if(en_miaobiao)
			mbms++;
		if(mbms==100)
		{
			mbms=0;
			sec++;
			if(sec==60)
			{
				min++;
				if(min==60)
					min=0;
			}
		}
	}
}


void send(uint key_num)
{	SBUF=key_num;
	while(!TI);
	TI=0;
}
